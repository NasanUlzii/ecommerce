import { redirect } from "next/navigation";

export default function ProfileWishlistPage() {
  redirect("/profile/wishlist/1");
}
