export default function SellerStoresPage() {
  return <div></div>;
}
