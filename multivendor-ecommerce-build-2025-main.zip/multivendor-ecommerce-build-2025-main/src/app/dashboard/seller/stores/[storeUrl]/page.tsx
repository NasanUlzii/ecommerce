export default function SellerStorePage() {
  return <div></div>;
}
