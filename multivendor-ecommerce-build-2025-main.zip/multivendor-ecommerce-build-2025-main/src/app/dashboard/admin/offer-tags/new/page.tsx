import OfferTagDetails from "@/components/dashboard/forms/offer-tag-details";

export default function AdminOfferTagsPage() {
  return (
    <div className="w-full">
      <OfferTagDetails />
    </div>
  );
}
