export default function AdminDashboardPage() {
  return <div>Admin dashboard</div>;
}
