import CategoryDetails from "@/components/dashboard/forms/category-details";

export default function AdminNewCategoryPage() {
  return (
    <div className="w-full">
      <CategoryDetails />
    </div>
  );
}
